import React, { useEffect, useState, lazy, Suspense, useCallback } from "react";

import { BrowserRouter as Router, Routes, Route } from "react-router-dom";

import Navbar from "./components/HeadernFooter/Navbar";
import BackButton from "./components/BackButton/BackButton";
import Hero from "./components/Hero";
import HeadingsSection from "./components/HeaderSection/HeadingsSection ";
import Login from "./components/Login&Reg/Login";
import RegisterPage from "./components/Login&Reg/Register";
import HelpCenter from "./components/HelpCenter/HelpCenter";
import SpecialDeals from "./components/SpecialDeals/SpecialDeals";

import AboutPage from "./components/AboutPage/AboutPage";
import TermsConditionsPage from "./components/TermsandConditions/TermsConditionsPage";

/* lazy-load below-the-fold / heavy components */

const NewPropertyCard = lazy(() => import("./components/newFetchCarousel"));
const TrendingProperties = lazy(() => import("./components/TrendingProperties"));
const Gallery = lazy(() => import("./components/Gallery"));
const Testimonials = lazy(() => import("./components/Testimonials/Testimonials"));
const Footer = lazy(() => import("./components/Footer/Footer"));

function App() {
  const [theme, setTheme] = useState("light");
  // control when to actually mount/load heavy lazy components
  const [loadHeavy, setLoadHeavy] = useState(false);

  // initialize AOS lazily (do not include in initial bundle)
  useEffect(() => {
    const loadAOS = () => {
      // load AOS stylesheet from CDN to avoid bundling CSS
      const href = "https://unpkg.com/aos@2.3.4/dist/aos.css";
      if (!document.querySelector(`link[href="${href}"]`)) {
        const link = document.createElement("link");
        link.rel = "stylesheet";
        link.href = href;
        document.head.appendChild(link);
      }

      import("aos")
        .then((mod) => {
          const AOS = (mod && (mod.default || mod));
          if (AOS && AOS.init) AOS.init({ duration: 800, once: true });
        })
        .catch(() => {
          /* ignore AOS load failure silently */
        });
    };

    if ("requestIdleCallback" in window) {
      window.requestIdleCallback(loadAOS, { timeout: 500 });
    } else {
      const t = setTimeout(loadAOS, 250);
      return () => clearTimeout(t);
    }
  }, []);

  // apply theme attribute when theme changes
  useEffect(() => {
    document.documentElement.setAttribute("data-theme", theme);
  }, [theme]);

  // header scroll handling (optimized with rAF)
  useEffect(() => {
    const header = document.querySelector(".navbar");
    if (!header) return;
    const headerHeight = header.offsetHeight;
    let ticking = false;

    const handleScroll = () => {
      if (ticking) return;
      ticking = true;
      requestAnimationFrame(() => {
        const scrollpos = window.scrollY;
        if (scrollpos >= headerHeight) header.classList.add("scrolled", "shadow-sm");
        else header.classList.remove("scrolled", "shadow-sm");
        ticking = false;
      });
    };

    window.addEventListener("scroll", handleScroll, { passive: true });
    handleScroll();
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  // defer mounting/loading heavy lazy components until idle/after a short delay
  useEffect(() => {
    const start = () => setLoadHeavy(true);
    if ("requestIdleCallback" in window) {
      window.requestIdleCallback(start, { timeout: 700 });
    } else {
      const t = setTimeout(start, 600);
      return () => clearTimeout(t);
    }
  }, []);

  const toggleTheme = useCallback(() => setTheme((t) => (t === "light" ? "dark" : "light")), []);

  return (
    <Router>
      <Navbar theme={theme} toggleTheme={toggleTheme} />
      <BackButton />
      <Suspense 
        fallback={
          <div className="text-center py-5">
            <div className="spinner-border text-primary" role="status">
              <span className="visually-hidden">Loading...</span>
            </div>
          </div>
        }
      >
        <Routes>
          {/* Home Route */}
          <Route 
            path="/" 
            element={
              <main className="main-content">
                <HeadingsSection />
                <Hero />
                   <NewPropertyCard />
            <Gallery />
           
       
     
              <Testimonials />
                 <TrendingProperties />
            <Footer />
              </main>
            } 
          />
          
          {/* Login Route */}
          <Route path="/login" element={<Login />} />
          
          {/* Register Route */}
           <Route path="/register" element={<RegisterPage/>} />
          
          {/* Help Center Route */}
          <Route path="/HelpCenter" element={<HelpCenter />} />
          
          {/* About Route */}
          <Route path="/about" element={<AboutPage />} />
          
          {/* Special Deals Route */}
          <Route path="/deals" element={<SpecialDeals />} /> 
          
          {/* Terms and Conditions Route */}
          <Route path="/terms" element={<TermsConditionsPage />} />
        </Routes>
      </Suspense>
    </Router>
  );
}

export default App;
