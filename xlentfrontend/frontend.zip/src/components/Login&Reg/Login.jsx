import React, { useState } from "react";
import { Link } from "react-router-dom";
import { 
  Mail, 
  Lock, 
  Eye, 
  EyeOff, 
  LogIn, 
  UserPlus, 
  Shield, 
  Smartphone,
  AlertCircle,
  CheckCircle,
  Sparkles
} from "lucide-react";
import './Login.css'

const Login = () => {
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [formData, setFormData] = useState({
    email: "",
    password: "",
    rememberMe: false
  });
  const [errors, setErrors] = useState({});

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
    // Clear error when user starts typing
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  const validateForm = () => {
    const newErrors = {};
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (!formData.email.trim()) {
      newErrors.email = 'Email is required';
    } else if (!emailRegex.test(formData.email)) {
      newErrors.email = 'Please enter a valid email address';
    }

    if (!formData.password) {
      newErrors.password = 'Password is required';
    } else if (formData.password.length < 6) {
      newErrors.password = 'Password must be at least 6 characters';
    }

    return newErrors;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const validationErrors = validateForm();

    if (Object.keys(validationErrors).length === 0) {
      setIsLoading(true);
      try {
        const res = await fetch(process.env.REACT_APP_API_BASE_URL ? `${process.env.REACT_APP_API_BASE_URL}/api/auth/login` : 'http://localhost:5000/api/auth/login', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email: formData.email, password: formData.password })
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.message || 'Login failed');
        // store token
        if (data.token) localStorage.setItem('xlent_token', data.token);
        alert('Login successful!');
      } catch (err) {
        console.error(err);
        setErrors({ form: err.message || 'Login error' });
      } finally {
        setIsLoading(false);
      }
    } else {
      setErrors(validationErrors);
    }
  };

  return (
    <div className="min-vh-100 d-flex align-items-center justify-content-center position-relative overflow-hidden">
      {/* Animated Background Elements */}
      <div className="position-absolute top-0 start-0 w-100 h-100">
        <div 
          className="position-absolute top-0 start-0 w-100 h-100"
          style={{
            backgroundImage: "url('/OrginalLogo.png')",
            backgroundSize: "cover",
            backgroundPosition: "center",
            backgroundRepeat: "no-repeat",
            backgroundColor: "rgba(255,255,255,0.92)",
            backgroundBlendMode: "overlay",
            animation: 'zoomInOut 20s infinite alternate'
          }}
        />
        
        {/* Animated gradient overlay */}
        <div 
          className="position-absolute top-0 start-0 w-100 h-100"
          style={{
            background: 'linear-gradient(45deg, rgba(2, 40, 124, 0.03) 0%, rgba(255, 255, 255, 0.95) 100%)',
            animation: 'gradientShift 10s ease-in-out infinite alternate'
          }}
        />
        
        {/* Floating elements */}
        <div className="position-absolute" style={{ top: '10%', left: '5%' }}>
          <div className="floating-element" style={{ animationDelay: '0s' }}>
            <div className="bg-primary bg-opacity-10 rounded-circle p-3">
              <Car size={24} className="text-primary" />
            </div>
          </div>
        </div>
        <div className="position-absolute" style={{ top: '70%', right: '8%' }}>
          <div className="floating-element" style={{ animationDelay: '1s' }}>
            <div className="bg-primary bg-opacity-10 rounded-circle p-3">
              <Shield size={24} className="text-primary" />
            </div>
          </div>
        </div>
        <div className="position-absolute" style={{ bottom: '20%', left: '15%' }}>
          <div className="floating-element" style={{ animationDelay: '2s' }}>
            <div className="bg-primary bg-opacity-10 rounded-circle p-3">
              <Smartphone size={24} className="text-primary" />
            </div>
          </div>
        </div>
      </div>

      {/* Main Login Card */}
      <div className="position-relative z-2" style={{ marginTop: '20px' }}>
        <div 
          className="card border-0 shadow-lg overflow-hidden animate-slide-up"
          style={{
            width: "480px",
            backdropFilter: "blur(10px)",
            backgroundColor: "rgba(255, 255, 255, 0.95)",
            borderRadius: "20px",
            borderTop: "5px solid rgb(2, 40, 124)"
          }}
        >
          {/* Card Header with gradient */}
          <div 
            className="text-center py-4 px-4"
            style={{
              background: 'linear-gradient(135deg, rgb(2, 40, 124) 0%, rgb(13, 110, 253) 100%)'
            }}
          >
            <div className="d-flex align-items-center justify-content-center mb-2">
              <div className="bg-white rounded-circle p-2 me-3 shadow-sm">
                <LogIn size={24} className="text-primary" />
              </div>
              <h2 className="text-white mb-0 fw-bold">Welcome Back</h2>
            </div>
            <p className="text-white-50 mb-0">Sign in to your Xlentcar account</p>
          </div>

          {/* Card Body */}
          <div className="card-body p-4 p-md-5">
            <form onSubmit={handleSubmit} noValidate>
              {/* Email Field */}
              <div className="mb-4">
                <label className="form-label fw-semibold d-flex align-items-center">
                  <Mail size={16} className="me-2 text-primary" />
                  Email Address
                </label>
                <div className="input-group input-group-lg">
                  <span className="input-group-text bg-light border-end-0">
                    <Mail size={18} className="text-muted" />
                  </span>
                  <input 
                    type="email"
                    name="email"
                    className={`form-control border-start-0 ${errors.email ? 'is-invalid' : ''}`}
                    placeholder="you@example.com"
                    value={formData.email}
                    onChange={handleChange}
                    style={{ borderRadius: "10px" }}
                  />
                </div>
                {errors.email && (
                  <div className="invalid-feedback d-flex align-items-center mt-2">
                    <AlertCircle size={14} className="me-2" />
                    {errors.email}
                  </div>
                )}
              </div>

              {/* Password Field */}
              <div className="mb-4">
                <label className="form-label fw-semibold d-flex align-items-center">
                  <Lock size={16} className="me-2 text-primary" />
                  Password
                </label>
                <div className="input-group input-group-lg">
                  <span className="input-group-text bg-light border-end-0">
                    <Lock size={18} className="text-muted" />
                  </span>
                  <input 
                    type={showPassword ? "text" : "password"}
                    name="password"
                    className={`form-control border-start-0 ${errors.password ? 'is-invalid' : ''}`}
                    placeholder="Enter your password"
                    value={formData.password}
                    onChange={handleChange}
                    style={{ borderRadius: "10px" }}
                  />
                  <button
                    type="button"
                    className="btn btn-outline-secondary border-start-0"
                    onClick={() => setShowPassword(!showPassword)}
                  >
                    {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                  </button>
                </div>
                {errors.password && (
                  <div className="invalid-feedback d-flex align-items-center mt-2">
                    <AlertCircle size={14} className="me-2" />
                    {errors.password}
                  </div>
                )}
              </div>

              {/* Remember Me & Forgot Password */}
              <div className="d-flex justify-content-between align-items-center mb-4">
                <div className="form-check">
                  <input 
                    type="checkbox" 
                    className="form-check-input"
                    name="rememberMe"
                    id="rememberMe"
                    checked={formData.rememberMe}
                    onChange={handleChange}
                  />
                  <label className="form-check-label" htmlFor="rememberMe">
                    Remember me
                  </label>
                </div>
                <Link 
                  to="/forgot-password" 
                  className="text-decoration-none fw-semibold"
                  style={{ color: "rgb(2, 40, 124)" }}
                >
                  Forgot password?
                </Link>
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                className="btn btn-primary btn-lg w-100 py-3 mb-3 d-flex align-items-center justify-content-center"
                disabled={isLoading}
                style={{
                  background: "linear-gradient(135deg, rgb(2, 40, 124) 0%, rgb(13, 110, 253) 100%)",
                  border: "none",
                  borderRadius: "12px",
                  transition: "all 0.3s ease"
                }}
                onMouseEnter={(e) => {
                  e.target.style.transform = "translateY(-2px)";
                  e.target.style.boxShadow = "0 10px 20px rgba(13, 110, 253, 0.3)";
                }}
                onMouseLeave={(e) => {
                  e.target.style.transform = "translateY(0)";
                  e.target.style.boxShadow = "none";
                }}
              >
                {isLoading ? (
                  <>
                    <span className="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                    Signing in...
                  </>
                ) : (
                  <>
                    <LogIn size={20} className="me-2" />
                    Sign In
                  </>
                )}
              </button>

              {/* Social Login Options */}
              <div className="text-center mb-4">
                <div className="position-relative">
                  <hr className="text-muted" />
                  <span className="position-absolute top-50 start-50 translate-middle bg-white px-3 text-muted small">
                    Or continue with
                  </span>
                </div>
                <div className="d-flex justify-content-center gap-3 mt-4">
                  <button type="button" className="btn btn-outline-primary rounded-circle p-3">
                    <i className="bi bi-google"></i>
                  </button>
                  <button type="button" className="btn btn-outline-primary rounded-circle p-3">
                    <i className="bi bi-facebook"></i>
                  </button>
                  <button type="button" className="btn btn-outline-primary rounded-circle p-3">
                    <i className="bi bi-apple"></i>
                  </button>
                </div>
              </div>

              {/* Sign Up Link */}
              <div className="text-center mt-4 pt-3 border-top">
                <p className="text-muted mb-2">
                  Don't have an account?{' '}
                  <Link 
                    to="/register" 
                    className="text-decoration-none fw-bold"
                    style={{ color: "rgb(2, 40, 124)" }}
                  >
                    <UserPlus size={16} className="me-1" />
                    Sign up here
                  </Link>
                </p>
                <div className="d-flex align-items-center justify-content-center mt-2">
                  <Shield size={14} className="text-success me-2" />
                  <span className="small text-muted">Your data is protected with 256-bit SSL encryption</span>
                </div>
              </div>
            </form>
          </div>

          {/* Stats Footer */}
          <div className="text-center py-3 bg-light border-top">
            <div className="row g-3">
              <div className="col-4">
                <div className="fw-bold text-primary">50K+</div>
                <div className="small text-muted">Users</div>
              </div>
              <div className="col-4">
                <div className="fw-bold text-primary">99.9%</div>
                <div className="small text-muted">Uptime</div>
              </div>
              <div className="col-4">
                <div className="fw-bold text-primary">24/7</div>
                <div className="small text-muted">Support</div>
              </div>
            </div>
          </div>
        </div>

        {/* Security Badge */}
        <div className="text-center mt-4">
          <div className="d-inline-flex align-items-center bg-white bg-opacity-75 rounded-pill px-4 py-2 shadow-sm">
            <Shield size={16} className="text-success me-2" />
            <span className="small fw-semibold">Secure Login • Encrypted Connection</span>
          </div>
        </div>
      </div>

      {/* Add these styles in your CSS file or in a style tag */}
      <style jsx>{`
        @keyframes zoomInOut {
          0% {
            transform: scale(1);
          }
          100% {
            transform: scale(1.05);
          }
        }
        
        @keyframes gradientShift {
          0% {
            opacity: 0.7;
          }
          100% {
            opacity: 0.9;
          }
        }
        
        @keyframes float {
          0%, 100% {
            transform: translateY(0) rotate(0deg);
          }
          50% {
            transform: translateY(-20px) rotate(5deg);
          }
        }
        
        @keyframes slideUp {
          from {
            opacity: 0;
            transform: translateY(30px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        
        .floating-element {
          animation: float 6s ease-in-out infinite;
        }
        
        .animate-slide-up {
          animation: slideUp 0.6s ease-out;
        }
        
        .form-control:focus {
          border-color: rgb(2, 40, 124);
          box-shadow: 0 0 0 0.25rem rgba(2, 40, 124, 0.25);
        }
        
        .btn-primary {
          transition: all 0.3s ease;
        }
        
        .btn-primary:hover {
          transform: translateY(-2px);
          box-shadow: 0 10px 20px rgba(2, 40, 124, 0.3);
        }
        
        .form-check-input:checked {
          background-color: rgb(2, 40, 124);
          border-color: rgb(2, 40, 124);
        }
      `}</style>
    </div>
  );
};

// Mock Car icon component (since it's not imported)
const Car = ({ size, className }) => (
  <svg 
    xmlns="http://www.w3.org/2000/svg" 
    width={size} 
    height={size} 
    viewBox="0 0 24 24" 
    fill="none" 
    stroke="currentColor" 
    strokeWidth="2" 
    strokeLinecap="round" 
    strokeLinejoin="round"
    className={className}
  >
    <path d="M19 17h2c.6 0 1-.4 1-1v-3c0-.9-.7-1.7-1.5-1.9C18.7 10.6 16 10 16 10s-1.3-1.4-2.2-2.3c-.5-.4-1.1-.7-1.8-.7H5c-.6 0-1.1.4-1.4.9l-1.4 2.9A3.7 3.7 0 0 0 2 12v4c0 .6.4 1 1 1h2" />
    <circle cx="7" cy="17" r="2" />
    <circle cx="17" cy="17" r="2" />
    <path d="M9 17h6" />
  </svg>
);

export default Login;