import React, { useState, useRef, useEffect } from "react";
import { Link } from "react-router-dom";
import "./Navbar.css";

const Navbar = ({ theme, toggleTheme }) => {
  const [showInvestingDropdown, setShowInvestingDropdown] = useState(false);
  const [showBorrowDropdown, setShowBorrowDropdown] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  
  const investingRef = useRef(null);
  const borrowRef = useRef(null);
  const navbarCollapseRef = useRef(null);

  // Close dropdowns when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (investingRef.current && !investingRef.current.contains(event.target)) {
        setShowInvestingDropdown(false);
      }
      if (borrowRef.current && !borrowRef.current.contains(event.target)) {
        setShowBorrowDropdown(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  // Close navbar menu on link click
  const closeMenu = () => {
    setIsMenuOpen(false);
    setShowInvestingDropdown(false);
    setShowBorrowDropdown(false);
    
    // Also close Bootstrap's collapse
    const navbarCollapse = navbarCollapseRef.current;
    if (navbarCollapse && navbarCollapse.classList.contains('show')) {
      const toggleButton = document.querySelector('[data-bs-target="#navbarSupportedContent"]');
      if (toggleButton) {
        toggleButton.click();
      }
    }
  };



  return (
    <>
    <nav 
      className="navbar navbar-expand-lg navbar-light fixed-top navbar-custom" 
      style={{
        backgroundColor: 'rgba(2, 40, 124, 1)',
        zIndex: 1111,
        boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
      }}
    >
      <div className="container-fluid px-3 px-md-5">
        {/* Brand on the left corner */}
        <a className="navbar-brand d-flex align-items-center" href="/" style={{ color: 'white' }}>
          <img src="/LogoTranWhite.png" alt="xlentcar Icon" width="60" height="50" className="d-inline-block align-text-top" />
          <span className="ms-2 fw-bolder navbar-brand-text">Xlentcar</span>
        </a>

        <button
          className="navbar-toggler navbar-toggler-custom"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarSupportedContent"
          aria-controls="navbarSupportedContent"
          aria-expanded="false"
          aria-label="Toggle navigation"
          style={{ borderColor: 'rgba(255, 255, 255, 0.5)' }}
        >
          <span className="navbar-toggler-icon" style={{ filter: 'invert(1)' }}></span>
        </button>

        <div className="collapse navbar-collapse justify-content-end" id="navbarSupportedContent" ref={navbarCollapseRef}>
  {/* Navigation options on the right */}
  <ul className="navbar-nav align-items-center navbar-nav-custom">
    {/* Fleet Dropdown */}
    <li className="nav-item dropdown" ref={investingRef}>
      <a 
        className="nav-link dropdown-toggle nav-link-custom" 
        href="#fleet"
        onClick={(e) => {
          e.preventDefault();
          setShowInvestingDropdown(!showInvestingDropdown);
        }}
        style={{ 
          cursor: 'pointer',
          color: 'white'
        }}
      >
        Our Fleet
      </a>
      {showInvestingDropdown && (
        <div 
          className="dropdown-menu show dropdown-menu-custom"
          style={{
            position: 'absolute',
            backgroundColor: 'white',
            border: '1px solid #dee2e6',
            borderRadius: '8px',
            boxShadow: '0 8px 25px rgba(0,0,0,0.15)',
            minWidth: '280px',
            padding: '1rem 0'
          }}
        >
          {[
            { name: "Economy Cars", description: "Fuel-efficient & budget-friendly" },
            { name: "SUVs & Crossovers", description: "Spacious for families & groups" },
            { name: "Luxury Vehicles", description: "Premium comfort & style" },
            { name: "Business Fleet", description: "Corporate rental solutions" }
          ].map((item, index) => (
            <div key={index}>
              <a 
                className="dropdown-item dropdown-item-custom" 
                href={`#${item.name.toLowerCase().replace(' ', '-')}`}
                onClick={closeMenu}
                style={{ 
                  padding: '0.75rem 1.5rem',
                  display: 'block',
                  textDecoration: 'none',
                  color: '#333',
                  transition: 'background-color 0.2s'
                }}
                onMouseEnter={(e) => e.target.style.backgroundColor = '#f8f9fa'}
                onMouseLeave={(e) => e.target.style.backgroundColor = 'transparent'}
              >
                <div style={{ fontWeight: '600', marginBottom: '0.25rem' }}>{item.name}</div>
                <div style={{ fontSize: '0.875rem', color: '#6c757d' }}>{item.description}</div>
              </a>
            </div>
          ))}
        </div>
      )}
    </li>

    {/* Locations Dropdown */}
    <li className="nav-item dropdown" ref={borrowRef}>
      <a 
        className="nav-link dropdown-toggle nav-link-custom" 
        href="#locations"
        onClick={(e) => {
          e.preventDefault();
          setShowBorrowDropdown(!showBorrowDropdown);
        }}
        style={{ 
          cursor: 'pointer',
          color: 'white'
        }}
      >
        Locations
      </a>
      {showBorrowDropdown && (
        <div 
          className="dropdown-menu show dropdown-menu-custom"
          style={{
            position: 'absolute',
            backgroundColor: 'white',
            border: '1px solid #dee2e6',
            borderRadius: '8px',
            boxShadow: '0 8px 25px rgba(0,0,0,0.15)',
            minWidth: '250px',
            padding: '1rem 0'
          }}
        >
          {[
            { name: "Airport Pickups", description: "Convenient airport locations" },
            { name: "City Centers", description: "Downtown rental offices" },
            { name: "Nationwide", description: "200+ locations across the India" },
            { name: "International", description: "Global rental partners" }
          ].map((item, index) => (
            <div key={index}>
              <a 
                className="dropdown-item dropdown-item-custom" 
                href={`#${item.name.toLowerCase().replace(' ', '-')}`}
                onClick={closeMenu}
                style={{ 
                  padding: '0.75rem 1.5rem',
                  display: 'block',
                  textDecoration: 'none',
                  color: '#333',
                  transition: 'background-color 0.2s'
                }}
                onMouseEnter={(e) => e.target.style.backgroundColor = '#f8f9fa'}
                onMouseLeave={(e) => e.target.style.backgroundColor = 'transparent'}
              >
                <div style={{ fontWeight: '600', marginBottom: '0.25rem' }}>{item.name}</div>
                <div style={{ fontSize: '0.875rem', color: '#6c757d' }}>{item.description}</div>
              </a>
            </div>
          ))}
        </div>
      )}
    </li>

    <li className="nav-item">
     <Link to="/deals" onClick={closeMenu} className="nav-link nav-link-custom"  style={{ color: 'white' }}>
        Special Deals
      </Link>
    </li>

    <li className="nav-item">
      <Link to='/about' onClick={closeMenu} className="nav-link nav-link-custom"  style={{ color: 'white' }}>
  About Us      </Link>
    </li>

    <li className="nav-item">
      <Link to="/HelpCenter" onClick={closeMenu} className="nav-link nav-link-custom" style={{ color: 'white' }}>
       HelpCenter
      </Link>
    </li>

    {/* Login & Sign Up Buttons */}
    <li className="nav-item nav-button-item">
      <button 
        className="btn login-btn nav-btn-custom"
        style={{
          background: 'transparent',
          color: 'white',
          border: '1px solid rgba(255, 255, 255, 0.3)',
          borderRadius: '25px',
          fontWeight: '600',
          fontSize: '0.9rem',
          transition: 'all 0.3s ease'
        }}
        onMouseEnter={(e) => {
          e.target.style.background = 'rgba(255, 255, 255, 0.1)';
          e.target.style.borderColor = 'rgba(255, 255, 255, 0.5)';
        }}
        onMouseLeave={(e) => {
          e.target.style.background = 'transparent';
          e.target.style.borderColor = 'rgba(255, 255, 255, 0.3)';
        }}
      >
       <Link to="/login" onClick={closeMenu} style={{ color: 'white', textDecoration: 'none' }}>
          Login
        </Link>
      </button>
    </li>

    <li className="nav-item nav-button-item">
      <button 
        className="btn signup-btn nav-btn-custom"
        style={{
          background: '#ff6b35',
          color: 'white',
          border: 'none',
          borderRadius: '25px',
          padding: '0.5rem 1.5rem',
          fontWeight: '600',
          fontSize: '0.9rem',
          transition: 'all 0.3s ease'
        }}
        onMouseEnter={(e) => {
          e.target.style.background = '#e55a2b';
          e.target.style.transform = 'translateY(-2px)';
        }}
        onMouseLeave={(e) => {
          e.target.style.background = '#ff6b35';
          e.target.style.transform = 'translateY(0)';
        }}
      >
<Link to="/register" onClick={closeMenu} style={{ color: 'white', textDecoration: 'none' }}>
          Register
        </Link>      </button>
    </li>
  </ul>
</div>
      </div>
    </nav>
    {/* {toLogin && <Login />}     */}
</>
  );
};

export default Navbar;